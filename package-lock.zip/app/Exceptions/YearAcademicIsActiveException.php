<?php

namespace App\Exceptions;

use Exception;

class YearAcademicIsActiveException extends Exception
{
}
