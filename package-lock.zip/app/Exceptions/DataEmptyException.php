<?php

namespace App\Exceptions;

use Exception;

class DataEmptyException extends Exception
{
    public function __construct() {}
}
