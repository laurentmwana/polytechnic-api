<?php

namespace App\Enums;

enum GenderEnum: string
{
    case MALE = "homme";

    case FEMALE = "femme";
}
