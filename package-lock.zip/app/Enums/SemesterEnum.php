<?php

namespace App\Enums;

enum SemesterEnum: string
{
    case SEMESTER_1 = "Semestre 1";
    case SEMESTER_2 = "Semestre 2";
}
