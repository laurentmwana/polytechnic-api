<?php

namespace App\Enums;

enum LevelProgrammeEnum: string
{
    case BEFORE = "ancien système";

    case AFTER = "nouveau système";
}
